# PLC Mini Project Manager – Assignment 2

Full-stack app with **JWT auth**, **Projects**, **Tasks**, **Smart Scheduler**, **SQLite/EF Core**.

## Run locally

### Backend
```bash
cd backend
dotnet run
# -> http://localhost:5090
```

### Frontend
```bash
cd frontend
npm install
# optional: echo VITE_API_URL=http://localhost:5090/api > .env.local
npm run dev  # -> http://localhost:5174
```

## Docker (prod-like)

```bash
docker compose build
docker compose up
# Frontend: http://localhost:5175
# API:      http://localhost:5090
# Frontend proxies /api to API
```

## Endpoints (high level)
- POST /api/auth/register | /api/auth/login
- GET/POST /api/projects
- GET/PUT/DELETE /api/projects/{id}
- GET/POST /api/projects/{id}/tasks
- PUT/DELETE /api/projects/{id}/tasks/{taskId}
- POST /api/v1/projects/{projectId}/schedule

> DB is auto-created on startup (EnsureCreated). Replace with migrations for production.


## CI/CD & Deployment (Assignment 3)

### GitHub Actions
- `.github/workflows/ci-backend.yml` builds/publishes .NET backend.
- `.github/workflows/ci-frontend.yml` builds Vite frontend.
- `.github/workflows/docker-publish.yml` publishes Docker images to GHCR.

### Render
- `render.yaml` defines two web services (API + Web). Update names/regions as needed.
- Set `VITE_API_URL` for the web service to your API public URL.

### Vercel (Frontend)
- `vercel.json` included. Replace `your-api-host.example.com` with your API URL.

### Loading & UX
- A reusable `Loading` component was added at `frontend/src/components/Loading.tsx`. Use it in pages (Dashboard/ProjectDetails/Login/Register) for async operations.


### Seeding
Optional demo data seeder is in `backend/Seed.cs`. You can call `await Api.Seed.Seeder.SeedAsync(db);` right after `EnsureCreated()` in `Program.cs`.
