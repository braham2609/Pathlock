import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Api } from '../api'
import type { Project } from '../types'

export default function Dashboard() {
  const [items, setItems] = useState<Project[]>([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [error, setError] = useState<string | null>(null)

  const load = async () => {
    try { setItems(await Api.listProjects()) } catch (e: any) { setError(e.message) }
  }
  useEffect(() => { load() }, [])

  const create = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    try {
      await Api.createProject(title, description || undefined)
      setTitle(''); setDescription(''); await load()
    } catch (e: any) { setError(e.message) }
  }

  const del = async (id: number) => {
    setError(null)
    try { await Api.deleteProject(id); await load() } catch (e: any) { setError(e.message) }
  }

  return (
    <div className="grid gap-4">
      <form onSubmit={create} className="card flex flex-col gap-3">
        <h2 className="text-lg font-semibold">Create Project</h2>
        {error && <div className="text-red-600">{error}</div>}
        <input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
        <textarea placeholder="Description (optional)" value={description} onChange={e => setDescription(e.target.value)} />
        <button>Create</button>
      </form>

      <div className="card">
        <h2 className="text-lg font-semibold mb-2">Your Projects</h2>
        <ul className="grid gap-2">
          {items.map(p => (
            <li key={p.id} className="flex items-center justify-between border p-3 rounded">
              <div>
                <Link to={`/projects/${p.id}`} className="underline font-medium">{p.title}</Link>
                {p.description && <div className="opacity-70">{p.description}</div>}
              </div>
              <button onClick={() => del(p.id)}>Delete</button>
            </li>
          ))}
          {!items.length && <p className="opacity-70">No projects yet</p>}
        </ul>
      </div>
    </div>
  )
}
