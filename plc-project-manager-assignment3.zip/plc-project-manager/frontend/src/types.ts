export type User = { email: string }
export type Project = { id: number; title: string; description?: string; createdAt: string }
export type TaskItem = { id: number; title: string; isCompleted: boolean; dueDate?: string | null; projectId: number }
