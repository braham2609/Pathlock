export default function Loading({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 opacity-70">
      <svg viewBox="0 0 24 24" width="20" height="20" className="animate-spin" aria-hidden="true">
        <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="4" strokeOpacity="0.2" />
        <path d="M22 12a10 10 0 0 0-10-10" fill="none" stroke="currentColor" strokeWidth="4" />
      </svg>
      <span>{label}</span>
    </div>
  )
}
