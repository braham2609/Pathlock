using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Api.Models;

public class User
{
    public int Id { get; set; }
    [Required, StringLength(100)] public string Email { get; set; } = string.Empty;
    [Required] public string PasswordHash { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public List<Project> Projects { get; set; } = new();
}

public class Project
{
    public int Id { get; set; }
    [Required, StringLength(100, MinimumLength = 3)] public string Title { get; set; } = string.Empty;
    [StringLength(500)] public string? Description { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // ownership
    public int UserId { get; set; }
    public User? User { get; set; }

    public List<TaskItem> Tasks { get; set; } = new();
}

public class TaskItem
{
    public int Id { get; set; }
    [Required] public string Title { get; set; } = string.Empty;
    public DateTime? DueDate { get; set; }
    public bool IsCompleted { get; set; }

    public int ProjectId { get; set; }
    public Project? Project { get; set; }
}
