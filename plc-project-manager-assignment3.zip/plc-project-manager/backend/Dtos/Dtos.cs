namespace Api.Dtos;

public record RegisterRequest(string Email, string Password);
public record LoginRequest(string Email, string Password);
public record AuthResponse(string Token, string Email);

public record ProjectCreateDto(string Title, string? Description);
public record ProjectUpdateDto(string? Title, string? Description);

public record TaskCreateDto(string Title, DateTime? DueDate);
public record TaskUpdateDto(string? Title, DateTime? DueDate, bool? IsCompleted);
