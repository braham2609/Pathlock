using Api.Data;
using Api.Models;
using Microsoft.EntityFrameworkCore;

namespace Api.Seed;

public static class Seeder
{
    public static async Task SeedAsync(AppDbContext db)
    {
        if (await db.Users.AnyAsync()) return;

        var user = new User { Email = "demo@example.com", PasswordHash = BCrypt.Net.BCrypt.HashPassword("demo1234") };
        db.Users.Add(user);
        await db.SaveChangesAsync();

        var p = new Project { Title = "Demo Project", Description = "Example data", UserId = user.Id };
        db.Projects.Add(p);
        await db.SaveChangesAsync();

        db.Tasks.AddRange(
            new TaskItem { Title = "Write docs", ProjectId = p.Id },
            new TaskItem { Title = "Build UI", ProjectId = p.Id },
            new TaskItem { Title = "Ship!", ProjectId = p.Id }
        );
        await db.SaveChangesAsync();
    }
}
