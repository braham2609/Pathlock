using Api.Data;
using Api.Dtos;
using Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Api.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public class ProjectsController(AppDbContext db) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)!);

    [HttpGet]
    public async Task<IActionResult> GetProjects()
    {
        var items = await db.Projects
            .Where(p => p.UserId == UserId)
            .OrderByDescending(p => p.CreatedAt)
            .ToListAsync();
        return Ok(items);
    }

    [HttpPost]
    public async Task<IActionResult> CreateProject([FromBody] ProjectCreateDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Title) || dto.Title.Length < 3 || dto.Title.Length > 100)
            return BadRequest(new { message = "Title must be 3–100 characters" });

        if (dto.Description is { Length: > 500 })
            return BadRequest(new { message = "Description max 500 chars" });

        var p = new Project
        {
            Title = dto.Title.Trim(),
            Description = dto.Description?.Trim(),
            UserId = UserId
        };
        db.Projects.Add(p);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetProjectById), new { id = p.Id }, p);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetProjectById(int id)
    {
        var p = await db.Projects.Include(x => x.Tasks).FirstOrDefaultAsync(x => x.Id == id && x.UserId == UserId);
        return p is null ? NotFound() : Ok(p);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteProject(int id)
    {
        var p = await db.Projects.FirstOrDefaultAsync(x => x.Id == id && x.UserId == UserId);
        if (p is null) return NotFound();
        db.Projects.Remove(p);
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> UpdateProject(int id, [FromBody] ProjectUpdateDto dto)
    {
        var p = await db.Projects.FirstOrDefaultAsync(x => x.Id == id && x.UserId == UserId);
        if (p is null) return NotFound();

        if (dto.Title is not null)
        {
            var t = dto.Title.Trim();
            if (t.Length < 3 || t.Length > 100) return BadRequest(new { message = "Title must be 3–100 characters" });
            p.Title = t;
        }
        if (dto.Description is not null)
        {
            if (dto.Description.Length > 500) return BadRequest(new { message = "Description max 500 chars" });
            p.Description = dto.Description.Trim();
        }
        await db.SaveChangesAsync();
        return Ok(p);
    }
}
