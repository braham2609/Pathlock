using Api.Data;
using Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Api.Controllers;

[ApiController]
[Authorize]
[Route("api/v1/projects/{projectId:int}/schedule")]
public class ScheduleController(AppDbContext db) : ControllerBase
{
    // Very simple scheduler: sort by DueDate, then incomplete first, and assign day slots starting tomorrow.
    public class SchedulePlanItem
    {
        public int TaskId { get; set; }
        public string Title { get; set; } = string.Empty;
        public DateTime? DueDate { get; set; }
        public DateTime PlannedDate { get; set; }
    }

    public record ScheduleInput(int? DailyLimit);
    public record ScheduleOutput(List<SchedulePlanItem> Plan);

    [HttpPost]
    public async Task<IActionResult> Plan(int projectId, [FromBody] ScheduleInput input)
    {
        var project = await db.Projects.Include(p => p.Tasks).FirstOrDefaultAsync(p => p.Id == projectId);
        if (project is null) return NotFound();

        var tasks = project.Tasks.Where(t => !t.IsCompleted).OrderBy(t => t.DueDate ?? DateTime.MaxValue).ThenBy(t => t.Id).ToList();

        int daily = Math.Max(1, input.DailyLimit ?? 3);
        var start = DateTime.UtcNow.Date.AddDays(1);
        var result = new List<SchedulePlanItem>();
        int i = 0;
        foreach (var t in tasks)
        {
            var dayOffset = i / daily;
            result.Add(new SchedulePlanItem
            {
                TaskId = t.Id,
                Title = t.Title,
                DueDate = t.DueDate,
                PlannedDate = start.AddDays(dayOffset)
            });
            i++;
        }

        return Ok(new ScheduleOutput(result));
    }
}
