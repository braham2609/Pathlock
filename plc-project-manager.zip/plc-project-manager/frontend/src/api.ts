const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5090/api'

function authHeaders() {
  const token = localStorage.getItem('token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

async function request(path: string, init: RequestInit = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...authHeaders(), ...(init.headers || {}) },
    ...init,
  })
  if (!res.ok) throw new Error(await res.text())
  if (res.status === 204) return undefined
  return res.json()
}

export const Api = {
  register: (email: string, password: string) => request('/auth/register', { method: 'POST', body: JSON.stringify({ email, password }) }),
  login: (email: string, password: string) => request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),

  listProjects: () => request('/projects'),
  createProject: (title: string, description?: string) => request('/projects', { method: 'POST', body: JSON.stringify({ title, description }) }),
  getProject: (id: number) => request(`/projects/${id}`),
  deleteProject: (id: number) => request(`/projects/${id}`, { method: 'DELETE' }),

  listTasks: (projectId: number) => request(`/projects/${projectId}/tasks`),
  addTask: (projectId: number, title: string, dueDate?: string | null) => request(`/projects/${projectId}/tasks`, { method: 'POST', body: JSON.stringify({ title, dueDate }) }),
  updateTask: (projectId: number, taskId: number, data: any) => request(`/projects/${projectId}/tasks/${taskId}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteTask: (projectId: number, taskId: number) => request(`/projects/${projectId}/tasks/${taskId}`, { method: 'DELETE' }),

  schedule: (projectId: number, dailyLimit = 3) => request(`/v1/projects/${projectId}/schedule`, { method: 'POST', body: JSON.stringify({ dailyLimit }) })
}
