import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Api } from '../api'
import type { TaskItem } from '../types'

export default function ProjectDetails() {
  const { id } = useParams()
  const projectId = Number(id)
  const [title, setTitle] = useState('')
  const [tasks, setTasks] = useState<TaskItem[]>([])
  const [newTask, setNewTask] = useState('')
  const [due, setDue] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [plan, setPlan] = useState<any[]>([])

  const load = async () => {
    try {
      const p = await Api.getProject(projectId)
      setTitle(p.title)
      setTasks(await Api.listTasks(projectId))
      setPlan([])
    } catch (e: any) { setError(e.message) }
  }
  useEffect(() => { load() }, [projectId])

  const addTask = async (e: React.FormEvent) => {
    e.preventDefault(); setError(null)
    try {
      await Api.addTask(projectId, newTask, due || null)
      setNewTask(''); setDue(''); await load()
    } catch (e: any) { setError(e.message) }
  }

  const toggle = async (t: TaskItem) => {
    await Api.updateTask(projectId, t.id, { isCompleted: !t.isCompleted })
    await load()
  }

  const del = async (t: TaskItem) => {
    await Api.deleteTask(projectId, t.id)
    await load()
  }

  const schedule = async () => {
    const res = await Api.schedule(projectId, 3)
    setPlan(res.plan)
  }

  return (
    <div className="grid gap-4">
      <div className="card">
        <h2 className="text-lg font-semibold">Project: {title}</h2>
        {error && <div className="text-red-600">{error}</div>}
        <form onSubmit={addTask} className="flex gap-2 mt-2">
          <input placeholder="Task title" value={newTask} onChange={e => setNewTask(e.target.value)} />
          <input type="date" value={due} onChange={e => setDue(e.target.value)} />
          <button>Add Task</button>
        </form>
      </div>

      <div className="card">
        <h3 className="font-semibold mb-2">Tasks</h3>
        <ul className="grid gap-2">
          {tasks.map(t => (
            <li key={t.id} className="flex items-center justify-between border p-3 rounded">
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={t.isCompleted} onChange={() => toggle(t)} />
                <span className={t.isCompleted ? 'line-through opacity-70' : ''}>{t.title}</span>
              </label>
              <div className="flex items-center gap-2">
                {t.dueDate && <span className="opacity-70">Due: {new Date(t.dueDate).toLocaleDateString()}</span>}
                <button onClick={() => del(t)}>Delete</button>
              </div>
            </li>
          ))}
          {!tasks.length && <p className="opacity-70">No tasks yet</p>}
        </ul>
      </div>

      <div className="card">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Smart Schedule</h3>
          <button onClick={schedule}>Generate Plan</button>
        </div>
        {!!plan.length && (
          <ul className="grid gap-2 mt-3">
            {plan.map((p: any, idx: number) => (
              <li key={idx} className="border p-2 rounded">
                {p.title} → {new Date(p.plannedDate).toLocaleDateString()} {p.dueDate ? `(due ${new Date(p.dueDate).toLocaleDateString()})` : ''}
              </li>
            ))}
          </ul>
        )}
        {!plan.length && <p className="opacity-70 mt-2">No plan yet</p>}
      </div>
    </div>
  )
}
