import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Api } from '../api'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true); setError(null)
    try {
      const res = await Api.login(email, password)
      localStorage.setItem('token', res.token)
      localStorage.setItem('email', res.email)
      navigate('/')
    } catch (e: any) {
      setError(e.message || 'Login failed')
    } finally { setLoading(false) }
  }

  return (
    <div className="max-w-md mx-auto card">
      <h2 className="text-xl font-semibold mb-3">Login</h2>
      {error && <div className="mb-2 text-red-600">{error}</div>}
      <form onSubmit={submit} className="flex flex-col gap-3">
        <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
        <input placeholder="Password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
        <button disabled={loading}>{loading ? 'Logging in…' : 'Login'}</button>
      </form>
      <p className="mt-3">No account? <Link to="/register" className="underline">Register</Link></p>
    </div>
  )
}
