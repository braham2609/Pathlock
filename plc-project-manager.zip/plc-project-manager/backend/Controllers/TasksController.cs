using Api.Data;
using Api.Dtos;
using Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Api.Controllers;

[ApiController]
[Authorize]
[Route("api/projects/{projectId:int}/[controller]")]
public class TasksController(AppDbContext db) : ControllerBase
{
    private int UserId => int.Parse(User.FindFirstValue(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)!);

    private async Task<Project?> GetProject(int projectId) =>
        await db.Projects.FirstOrDefaultAsync(p => p.Id == projectId && p.UserId == UserId);

    [HttpGet]
    public async Task<IActionResult> List(int projectId)
    {
        var p = await GetProject(projectId);
        if (p is null) return NotFound();
        var tasks = await db.Tasks.Where(t => t.ProjectId == p.Id).OrderBy(t => t.Id).ToListAsync();
        return Ok(tasks);
    }

    [HttpPost]
    public async Task<IActionResult> Create(int projectId, [FromBody] TaskCreateDto dto)
    {
        var p = await GetProject(projectId);
        if (p is null) return NotFound();
        if (string.IsNullOrWhiteSpace(dto.Title)) return BadRequest(new { message = "Title required" });

        var t = new TaskItem { Title = dto.Title.Trim(), DueDate = dto.DueDate, ProjectId = p.Id };
        db.Tasks.Add(t);
        await db.SaveChangesAsync();
        return Created($"/api/projects/{projectId}/tasks/{t.Id}", t);
    }

    [HttpPut("{taskId:int}")]
    public async Task<IActionResult> Update(int projectId, int taskId, [FromBody] TaskUpdateDto dto)
    {
        var p = await GetProject(projectId);
        if (p is null) return NotFound();
        var t = await db.Tasks.FirstOrDefaultAsync(x => x.Id == taskId && x.ProjectId == p.Id);
        if (t is null) return NotFound();

        if (dto.Title is not null) t.Title = dto.Title.Trim();
        if (dto.DueDate.HasValue) t.DueDate = dto.DueDate;
        if (dto.IsCompleted.HasValue) t.IsCompleted = dto.IsCompleted.Value;

        await db.SaveChangesAsync();
        return Ok(t);
    }

    [HttpDelete("{taskId:int}")]
    public async Task<IActionResult> Delete(int projectId, int taskId)
    {
        var p = await GetProject(projectId);
        if (p is null) return NotFound();
        var t = await db.Tasks.FirstOrDefaultAsync(x => x.Id == taskId && x.ProjectId == p.Id);
        if (t is null) return NotFound();

        db.Tasks.Remove(t);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
