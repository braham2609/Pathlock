# PLC Mini Project Manager – Assignment 2

Full-stack app with **JWT auth**, **Projects**, **Tasks**, **Smart Scheduler**, **SQLite/EF Core**.

## Run locally

### Backend
```bash
cd backend
dotnet run
# -> http://localhost:5090
```

### Frontend
```bash
cd frontend
npm install
# optional: echo VITE_API_URL=http://localhost:5090/api > .env.local
npm run dev  # -> http://localhost:5174
```

## Docker (prod-like)

```bash
docker compose build
docker compose up
# Frontend: http://localhost:5175
# API:      http://localhost:5090
# Frontend proxies /api to API
```

## Endpoints (high level)
- POST /api/auth/register | /api/auth/login
- GET/POST /api/projects
- GET/PUT/DELETE /api/projects/{id}
- GET/POST /api/projects/{id}/tasks
- PUT/DELETE /api/projects/{id}/tasks/{taskId}
- POST /api/v1/projects/{projectId}/schedule

> DB is auto-created on startup (EnsureCreated). Replace with migrations for production.
