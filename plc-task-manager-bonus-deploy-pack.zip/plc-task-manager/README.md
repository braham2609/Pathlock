# PLC Task Manager – Assignment 1

Full-stack minimal app using **.NET 8** + **React TypeScript**.

## Run

### Backend
```bash
cd backend
dotnet run
# http://localhost:5089
```

### Frontend
```bash
cd frontend
npm install
# optional: echo VITE_API_URL=http://localhost:5089/api > .env.local
npm run dev
# http://localhost:5173
```


## Docker (build & run)

```bash
# From project root
docker compose build
docker compose up
# Frontend: http://localhost:5173  (served by Nginx)
# API:      http://localhost:5089
```

The frontend container proxies `/api` to the backend automatically.

## TailwindCSS

Already configured. In the frontend folder:

```bash
npm install
npm run dev
```
Utility classes like `px-3 py-1 rounded border` are now active.


## Bonus: Deploy

### Vercel (Frontend)
- Add `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID` to GitHub repo secrets.
- Run workflow **Deploy Frontend to Vercel** or push to `main`.

### Render (API + Web)
- Create a Render API key; save as `RENDER_API_KEY` secret in GitHub.
- Update `render.yaml` env vars if needed.
- Run **Deploy to Render (Blueprint)**.

### Environment
- Frontend expects `VITE_API_URL` at build time.
- In Docker/Render, Nginx proxies `/api` to the API.
